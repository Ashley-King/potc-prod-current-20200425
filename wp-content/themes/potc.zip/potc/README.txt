MAI LIFESTYLE PRO THEME
https://maitheme.com

INSTALL
1. Upload the Mai Lifestyle Pro theme folder via the WordPress dashboard, Appearances > Themes > Add New or manually via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Mai Lifestyle Pro theme via Appearances > Themes in your WordPress dashboard.
4. Customize your site via your wordpress dashboard Appearances > Customize and configure to your liking.

SUPPORT
Please visit http://support.bizbudding.com/ for theme support.

CHANGELOG

= 1.3.0 =
* Changed: Version bump for theme consistency.

= 1.2.0
* Added: noopener rel tag to footer credits.
* Changed: More refined base CSS.
* Changed: Correct order of starter mobile-first CSS breakpoints.
* Changed: Updated screenshot.
* Changed: Updated dependency installer to latest version.
* Changed: Now use Composer for dependencies.

= 1.1.0
* Changed: New default fonts.
* Changed: Dependency now points to the final location for Mai Theme Engine.

= 1.0.2 =
* Changed: Update dependency loader to latest version.

= 1.0.1 =
* Changed: Update dependency loader with new repo location.

= 1.0.0 =
* Initial release.
