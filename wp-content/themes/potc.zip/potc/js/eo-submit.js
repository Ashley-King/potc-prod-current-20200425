jQuery("document").ready(function(){
    
    jQuery(".email-octopus-form").submit(function(){
   
      jQuery.ajax({
        type: "POST",
        dataType: "json",
        url: "/wp-content/themes/potc/js/add-eo.php", 
        data: jQuery(".email-octopus-form").serialize(),
        // contentType: "application/json; charset=utf-8",
        success: function(newData) {
            //"code":"MEMBER_EXISTS_WITH_EMAIL_ADDRESS
            if(newData.id){
                alert("membership pending");
            }else if(newData.message){
                alert(newData.message);
            }
            else{
                alert(JSON.stringify(newData));
            }
            jQuery('input[name="field_1"], input[name="field_0"]').val('');
        },
        
      });
      
      return false;
    });
  });


