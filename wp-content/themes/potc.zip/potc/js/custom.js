jQuery(document).ready(function($){
    //customize email octopus forms
    $('input[name="FirstName"').attr('placeholder', "Enter your first name...");
    $('input[name="EmailAddress"').attr('placeholder', "Enter your email...");
    $('.emailoctopus-label').remove();

    //change logo on about page & blog page
    $('.sub_page .site-title .custom-logo-link img').replaceWith('<img width="1222" height="259" src="http://local.mai-potc/wp-content/uploads/2020/01/cropped-logo-green1-1.png" class="custom-logo" alt="pediatricOTcourses" srcset="http://local.mai-potc/wp-content/uploads/2020/01/cropped-logo-green1-1.png 1222w, http://local.mai-potc/wp-content/uploads/2020/01/cropped-logo-green1-1-300x64.png 300w, http://local.mai-potc/wp-content/uploads/2020/01/cropped-logo-green1-1-1024x217.png 1024w, http://local.mai-potc/wp-content/uploads/2020/01/cropped-logo-green1-1-768x163.png 768w" sizes="(max-width: 1222px) 100vw, 1222px">');


});